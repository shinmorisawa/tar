#include <stdio.h>

int main() {
    printf("hello there!\n");
    return 0;
}
